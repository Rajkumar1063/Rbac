import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Container,
  TableContainer,
  Table as MuiTable,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Button,
  IconButton,
  Tooltip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Box,
  Grid,
  Typography,
  TablePagination,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import ClearIcon from "@mui/icons-material/Clear";

function SalesData({ userRole, onBack }) {
  const [sales, setSales] = useState([]);
  const [filteredSales, setFilteredSales] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingSale, setEditingSale] = useState(null);

  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    fetchSalesData();
  }, []);

  useEffect(() => {
    handleSearch();
  }, [searchQuery, sales]);

  const fetchSalesData = () => {
    axios
      .get("/api/sales")
      .then((response) => {
        setSales(response.data);
        setFilteredSales(response.data);
      })
      .catch((error) => console.error("Error fetching sales data:", error));
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setFilteredSales(sales);
    } else {
      const lowerCaseQuery = searchQuery.toLowerCase();
      setFilteredSales(
        sales.filter((sale) =>
          sale.product.toLowerCase().includes(lowerCaseQuery)
        )
      );
    }
  };

  const handleAddSale = () => {
    setEditingSale(null);
    setShowModal(true);
  };

  const handleEditSale = (sale) => {
    setEditingSale(sale);
    setShowModal(true);
  };

  const handleDeleteSale = (saleId) => {
    axios
      .delete(`/api/sales/${saleId}`)
      .then(() => fetchSalesData())
      .catch((error) => console.error("Error deleting sale:", error));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const sale = {
      id: editingSale ? editingSale.id : Date.now(),
      product: form.product.value,
      amount: form.amount.value,
      date: form.date.value,
    };

    const apiCall = editingSale
      ? axios.put(`/api/sales/${sale.id}`, sale)
      : axios.post("/api/sales", sale);

    apiCall
      .then(() => {
        fetchSalesData();
        setShowModal(false);
      })
      .catch((error) => console.error("Error saving sale:", error));
  };

  const handleSort = (field) => {
    const sortedSales = [...filteredSales].sort((a, b) => {
      if (field === "date") {
        return new Date(a[field]) - new Date(b[field]);
      }
      return a[field] > b[field] ? 1 : -1;
    });
    setFilteredSales(sortedSales);
  };

  const handleResetSearch = () => {
    setSearchQuery("");
    setFilteredSales(sales);
    setShowSearch(false); //
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset to the first page when rows per page change
  };
  return (
    <Box sx={{ bgcolor: "#fafafa", p: 4, minHeight: "100vh" }}>
      <Container maxWidth="lg">
        <Typography
          variant="h4"
          sx={{ fontWeight: "bold", mb: 3 }}
          color="primary"
        >
          Sales Data
        </Typography>

        <Grid container spacing={3} alignItems="center" className="mb-3">
          <Grid item xs={12} sm={4}>
            <Tooltip title="Add Sale">
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddSale}
                fullWidth
                sx={{
                  backgroundColor: "#4caf50",
                  "&:hover": { backgroundColor: "#388e3c" },
                  fontWeight: "bold",
                }}
              >
                Add Sale
              </Button>
            </Tooltip>
          </Grid>
          <Grid item xs={12} sm={4}>
            {showSearch ? (
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <TextField
                  fullWidth
                  placeholder="Search by Product Name"
                  variant="outlined"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  InputProps={{
                    startAdornment: <SearchIcon sx={{ mr: 1 }} />,
                  }}
                  sx={{ marginBottom: 2 }}
                />
                <IconButton onClick={handleResetSearch}>
                  <ClearIcon sx={{ color: "#f44336" }} />{" "}
                  {/* Reset Search Icon */}
                </IconButton>
              </Box>
            ) : (
              <Button
                variant="contained"
                color="secondary"
                startIcon={<SearchIcon />}
                onClick={() => setShowSearch(true)}
                fullWidth
                sx={{
                  backgroundColor: "#ff9800",
                  "&:hover": { backgroundColor: "#f57c00" },
                  fontWeight: "bold",
                }}
              >
                Search
              </Button>
            )}
          </Grid>
          <Grid item xs={12} sm={4}>
            <Button
              variant="outlined"
              color="primary"
              onClick={() => handleSort("date")}
              fullWidth
              sx={{
                borderColor: "#2196f3",
                "&:hover": { borderColor: "#1976d2" },
                fontWeight: "bold",
              }}
            >
              Sort by Date
            </Button>
          </Grid>
        </Grid>

        <TableContainer
          component={Paper}
          elevation={4}
          sx={{ borderRadius: 2 }}
        >
          <MuiTable>
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    backgroundColor: "#4caf50",
                    color: "white",
                    fontWeight: "bold",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "#388e3c",
                    },
                  }}
                  onClick={() => handleSort("product")}
                >
                  Product
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#ff9800",
                    color: "white",
                    fontWeight: "bold",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "#f57c00",
                    },
                  }}
                  onClick={() => handleSort("amount")}
                >
                  Amount
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#2196f3",
                    color: "white",
                    fontWeight: "bold",
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor: "#1976d2",
                    },
                  }}
                  onClick={() => handleSort("date")}
                >
                  Date
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor: "#9c27b0",
                    color: "white",
                    fontWeight: "bold",
                    textAlign: "center",
                  }}
                >
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredSales
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((sale) => (
                  <TableRow key={sale.id}>
                    <TableCell>{sale.product}</TableCell>
                    <TableCell>{sale.amount}</TableCell>
                    <TableCell>{sale.date}</TableCell>
                    <TableCell sx={{ textAlign: "center" }}>
                      <IconButton
                        color="primary"
                        onClick={() => handleEditSale(sale)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        color="secondary"
                        onClick={() => handleDeleteSale(sale.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </MuiTable>
        </TableContainer>

        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[15, 25, 50]}
          component="div"
          count={filteredSales.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />

        {/* Modal for adding/editing sales */}
        <Dialog open={showModal} onClose={() => setShowModal(false)}>
          <DialogTitle>{editingSale ? "Edit Sale" : "Add Sale"}</DialogTitle>
          <DialogContent>
            <form onSubmit={handleFormSubmit}>
              <TextField
                label="Product"
                name="product"
                defaultValue={editingSale ? editingSale.product : ""}
                fullWidth
                required
                sx={{ marginBottom: 2 }}
              />
              <TextField
                label="Amount"
                name="amount"
                type="number"
                defaultValue={editingSale ? editingSale.amount : ""}
                fullWidth
                required
                sx={{ marginBottom: 2 }}
              />
              <TextField
                label="Date"
                name="date"
                type="date"
                defaultValue={editingSale ? editingSale.date : ""}
                fullWidth
                required
                InputLabelProps={{
                  shrink: true,
                }}
                sx={{ marginBottom: 2 }}
              />
              <DialogActions>
                <Button onClick={() => setShowModal(false)} color="secondary">
                  Cancel
                </Button>
                <Button type="submit" color="primary">
                  Save
                </Button>
              </DialogActions>
            </form>
          </DialogContent>
        </Dialog>
      </Container>
    </Box>
  );
}

export default SalesData;
