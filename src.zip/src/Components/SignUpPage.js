import React, { useState } from 'react';
import { Container, Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function SignUpPage() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Data Analyst');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    axios.post('/api/register', { userId, password, role })
      .then(response => {
        if (response.data.isRegistered) {
          alert('User registered successfully!');
          navigate('/');
        } else {
          setError(response.data.message || 'Registration failed. Please try again.');
        }
      });
  };

  return (
    <Container>
      <h1>Sign Up</h1>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="userId">
          <Form.Label>User ID</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter user ID" 
            value={userId} 
            onChange={(e) => setUserId(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group controlId="password">
          <Form.Label>Password</Form.Label>
          <Form.Control 
            type="password" 
            placeholder="Enter password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </Form.Group>
        {error && <p className="text-danger">{error}</p>}
        <Form.Group controlId="role">
          <Form.Label>Role</Form.Label>
          <Form.Check 
            type="radio" 
            label="Data Analyst" 
            name="role" 
            value="Data Analyst" 
            checked={role === 'Data Analyst'} 
            onChange={(e) => setRole(e.target.value)} 
          />
          <Form.Check 
            type="radio" 
            label="Compliance Officer" 
            name="role" 
            value="Compliance Officer" 
            checked={role === 'Compliance Officer'} 
            onChange={(e) => setRole(e.target.value)} 
          />
          <Form.Check 
            type="radio" 
            label="System Admin" 
            name="role" 
            value="System Admin" 
            checked={role === 'System Admin'} 
            onChange={(e) => setRole(e.target.value)} 
          />
        </Form.Group>
        <Button variant="primary" type="submit">Register</Button>
      </Form>
    </Container>
  );
}

export default SignUpPage;
