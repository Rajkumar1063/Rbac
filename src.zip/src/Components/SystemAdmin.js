import React, { useState } from 'react';
import PermissionRequest from './PermissionRequest';
import RoleManagement from './RoleManagement';
import SalesData from './SalesData';
import { Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';
import LogoutButton from './LogoutButton';

function SystemAdmin() {
  const [showRoleManagement, setShowRoleManagement] = useState(false);
  const [showSalesData, setShowSalesData] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Data Analyst');
  const [error, setError] = useState('');

  const handleViewRolesClick = () => {
    setShowRoleManagement(true);
    setShowSalesData(false);
  };

  const handleViewSalesClick = () => {
    setShowSalesData(true);
    setShowRoleManagement(false);
  };

  const handleBackClick = () => {
    setShowRoleManagement(false);
    setShowSalesData(false);
  };

  const handleAddUser = () => {
    setShowAddUserModal(true);
  };

  const handleAddUserSubmit = (e) => {
    e.preventDefault();

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    axios.post('/api/register', { userId, password, role })
      .then(response => {
        if (response.data.isRegistered) {
          alert('User registered successfully!');
          setShowAddUserModal(false);
          setUserId('');
          setPassword('');
          setRole('Data Analyst');
          setError('');
        } else {
          setError(response.data.message || 'Registration failed. Please try again.');
        }
      })
      .catch(error => {
        setError('An error occurred. Please try again.');
      });
  };

  return (
    <div>
      <h2>System Admin Dashboard</h2>
      {!showRoleManagement && !showSalesData ? (
        <>
          <p>Manage users, view tables, and see other user's information and roles.</p>
          <button className="btn btn-primary mb-3" onClick={handleViewSalesClick}>
            View Sales Data
          </button>
          <button className="btn btn-secondary mb-3 ml-3" onClick={handleViewRolesClick}>
            View User Roles
          </button>
          <button className="btn btn-success mb-3 ml-3" onClick={handleAddUser}>
            Add User
          </button>
          <PermissionRequest userRole="System Admin" />
        </>
      ) : null}
      {showRoleManagement && (
        <>
          <RoleManagement userRole="System Admin" onBack={handleBackClick} />
        </>
      )}
      {showSalesData && (
        <>
          <SalesData userRole="System Admin" onBack={handleBackClick} />
        </>
      )}
      <LogoutButton />

      <Modal show={showAddUserModal} onHide={() => setShowAddUserModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add New User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleAddUserSubmit}>
            <Form.Group controlId="userId">
              <Form.Label>User ID</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="Enter user ID" 
                value={userId} 
                onChange={(e) => setUserId(e.target.value)} 
                required 
              />
            </Form.Group>
            <Form.Group controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control 
                type="password" 
                placeholder="Enter password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
              />
            </Form.Group>
            {error && <p className="text-danger">{error}</p>}
            <Form.Group controlId="role">
              <Form.Label>Role</Form.Label>
              <Form.Check 
                type="radio" 
                label="Data Analyst" 
                name="role" 
                value="Data Analyst" 
                checked={role === 'Data Analyst'} 
                onChange={(e) => setRole(e.target.value)} 
              />
              <Form.Check 
                type="radio" 
                label="Compliance Officer" 
                name="role" 
                value="Compliance Officer" 
                checked={role === 'Compliance Officer'} 
                onChange={(e) => setRole(e.target.value)} 
              />
              <Form.Check 
                type="radio" 
                label="System Admin" 
                name="role" 
                value="System Admin" 
                checked={role === 'System Admin'} 
                onChange={(e) => setRole(e.target.value)} 
              />
            </Form.Group>
            <Button variant="primary" type="submit">Add User</Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default SystemAdmin;
