import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';

function RoleManagement({ userRole, onBack }) {
  const [users, setUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [newRole, setNewRole] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    axios.get('/api/users')
      .then(response => setUsers(response.data))
      .catch(error => console.error('Error fetching users:', error));
  };

  const handleAddRole = () => {
    setEditingUser(null);
    setShowModal(true);
  };

  const handleEditRole = (user) => {
    setEditingUser(user);
    setNewRole(user.role);
    setShowModal(true);
  };

  const handleDeleteRole = (userId) => {
    axios.put(`/api/users/${userId}`, { role: '' }) // Clear role
      .then(() => fetchUsers())
      .catch(error => console.error('Error updating user:', error));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const updatedUser = {
      ...editingUser,
      role: newRole,
    };

    axios.put(`/api/users/${updatedUser.id}`, updatedUser)
      .then(() => {
        fetchUsers();
        setShowModal(false);
      })
      .catch(error => console.error('Error updating user:', error));
  };

  return (
    <div>
      <h2>User Information and Roles</h2>
      {userRole === 'System Admin' ? (
        <div className="mb-3">
          <Button className="mr-2" onClick={handleAddRole}>Add Role</Button>
        </div>
      ) : null}
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Role</th>
            <th>Status</th>
            {userRole === 'System Admin' ? <th>Actions</th> : null}
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.userId}</td>
              <td>{user.role}</td>
              <td>{user.status}</td>
              {userRole === 'System Admin' ? (
                <td>
                  <Button className="mr-2 mb-2" onClick={() => handleEditRole(user)}>Edit Role</Button>
                  <Button variant="danger" className="mb-2" onClick={() => handleDeleteRole(user.id)}>Delete Role</Button>
                </td>
              ) : null}
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{editingUser ? 'Edit Role' : 'Add Role'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleFormSubmit}>
            <Form.Group controlId="role">
              <Form.Label>Role</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="Enter role" 
                value={newRole} 
                onChange={(e) => setNewRole(e.target.value)} 
                required 
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              {editingUser ? 'Update Role' : 'Add Role'}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      <Button onClick={onBack} className="mt-3">Back</Button>
    </div>
  );
}

export default RoleManagement;
