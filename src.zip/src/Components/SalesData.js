import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';

function SalesData({ userRole, onBack }) {
  const [sales, setSales] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingSale, setEditingSale] = useState(null);

  useEffect(() => {
    fetchSalesData();
  }, []);

  const fetchSalesData = () => {
    axios.get('/api/sales')
      .then(response => setSales(response.data))
      .catch(error => console.error('Error fetching sales data:', error));
  };

  const handleAddSale = () => {
    setEditingSale(null);
    setShowModal(true);
  };

  const handleEditSale = (sale) => {
    setEditingSale(sale);
    setShowModal(true);
  };

  const handleDeleteSale = (saleId) => {
    axios.delete(`/api/sales/${saleId}`)
      .then(() => fetchSalesData())
      .catch(error => console.error('Error deleting sale:', error));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const sale = {
      id: editingSale ? editingSale.id : Date.now(),
      product: form.product.value,
      amount: form.amount.value,
      date: form.date.value
    };

    const apiCall = editingSale 
      ? axios.put(`/api/sales/${sale.id}`, sale)
      : axios.post('/api/sales', sale);

    apiCall
      .then(() => {
        fetchSalesData();
        setShowModal(false);
      })
      .catch(error => console.error('Error saving sale:', error));
  };

  const handleSort = (field) => {
    const sortedSales = [...sales].sort((a, b) => {
      if (field === 'date') {
        return new Date(a[field]) - new Date(b[field]);
      }
      return a[field] > b[field] ? 1 : -1;
    });
    setSales(sortedSales);
  };

  return (
    <div>
      <h2>Sales Data</h2>
      <div className="d-flex mb-3">
        <Button className="mr-2" onClick={handleAddSale}>Add Sale</Button>
        <Button onClick={() => handleSort('date')}>Sort by Date</Button>
      </div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th onClick={() => handleSort('product')}>Product</th>
            <th onClick={() => handleSort('amount')}>Amount</th>
            <th onClick={() => handleSort('date')}>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {sales.map(sale => (
            <tr key={sale.id}>
              <td>{sale.product}</td>
              <td>{sale.amount}</td>
              <td>{sale.date}</td>
              <td>
                <Button className="mr-2 mb-2" onClick={() => handleEditSale(sale)}>Edit</Button>
                <Button variant="danger" className="mb-2" onClick={() => handleDeleteSale(sale.id)}>Delete</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{editingSale ? 'Edit Sale' : 'Add Sale'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleFormSubmit}>
            <Form.Group controlId="product">
              <Form.Label>Product</Form.Label>
              <Form.Control 
                type="text" 
                defaultValue={editingSale ? editingSale.product : ''} 
                required 
              />
            </Form.Group>
            <Form.Group controlId="amount">
              <Form.Label>Amount</Form.Label>
              <Form.Control 
                type="number" 
                defaultValue={editingSale ? editingSale.amount : ''} 
                required 
              />
            </Form.Group>
            <Form.Group controlId="date">
              <Form.Label>Date</Form.Label>
              <Form.Control 
                type="date" 
                defaultValue={editingSale ? editingSale.date : ''} 
                required 
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              {editingSale ? 'Update Sale' : 'Add Sale'}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      <Button onClick={onBack} className="mt-3">Back</Button>
    </div>
  );
}

export default SalesData;
