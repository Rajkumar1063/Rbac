import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Form, Button, Container } from 'react-bootstrap';

function LoginPage() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Clear inputs on component mount
  useEffect(() => {
    setUserId('');
    setPassword('');
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('/api/authenticate', { userId, password })
      .then((response) => {
        const { isAuthenticated, role } = response.data;
        if (isAuthenticated) {
          if (role === 'System Admin') {
            navigate('/SystemAdmin');
          } else if (role === 'Compliance Officer') {
            navigate('/ComplianceOfficer');
          } else if (role === 'Data Analyst') {
            navigate('/DataAnalyst');
          } else {
            setError('Invalid role. Please contact the administrator.');
          }
        } else {
          setError('Invalid credentials. Please try again.');
        }
      })
      .catch(() => {
        setError('An error occurred. Please try again.');
      });
  };

  return (
    <Container>
      <h1>Login</h1>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="userId">
          <Form.Label>User ID</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter user ID"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group controlId="password">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </Form.Group>
        {error && <p className="text-danger">{error}</p>}
        <Button variant="primary" type="submit">Login</Button>
      </Form>
    </Container>
  );
}

export default LoginPage;
