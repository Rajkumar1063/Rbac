import React, { useState } from 'react';
import PermissionRequest from './PermissionRequest';
import SalesData from './SalesData';
import LogoutButton from './LogoutButton';

function DataAnalyst() {
  const [showSalesData, setShowSalesData] = useState(false);

  const handleViewSalesClick = () => {
    setShowSalesData(true);
  };

  const handleBackClick = () => {
    setShowSalesData(false);
  };

  return (
    <div>
      <h2>Data Analyst Dashboard</h2>
      {!showSalesData ? (
        <>
          <p>View different tables and request extra permissions.</p>
          <button className="btn btn-primary mb-3" onClick={handleViewSalesClick}>
            View Sales Data
          </button>
          <PermissionRequest userRole="Data Analyst" />
        </>
      ) : (
        <>
          <SalesData userRole="Data Analyst" onBack={handleBackClick} />
        </>
      )}
      <LogoutButton />
    </div>
  );
}

export default DataAnalyst;
