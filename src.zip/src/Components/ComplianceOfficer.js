import React, { useState } from 'react';
import RoleManagement from './RoleManagement';
import SalesData from './SalesData';
import LogoutButton from './LogoutButton';

function ComplianceOfficer() {
  const [showRoleManagement, setShowRoleManagement] = useState(false);
  const [showSalesData, setShowSalesData] = useState(false);

  const handleViewRolesClick = () => {
    setShowRoleManagement(true);
    setShowSalesData(false);
  };

  const handleViewSalesClick = () => {
    setShowSalesData(true);
    setShowRoleManagement(false);
  };

  const handleBackClick = () => {
    setShowRoleManagement(false);
    setShowSalesData(false);
  };

  return (
    <div>
      <h2>Compliance Officer Dashboard</h2>
      {!showRoleManagement && !showSalesData ? (
        <>
          <p>View different tables and other user's information and roles.</p>
          <button className="btn btn-primary mb-3" onClick={handleViewSalesClick}>
            View Sales Data
          </button>
          <button className="btn btn-secondary mb-3 ml-3" onClick={handleViewRolesClick}>
            View User Roles
          </button>
        </>
      ) : null}
      {showRoleManagement && (
        <>
          <RoleManagement userRole="Compliance Officer" onBack={handleBackClick} />
        </>
      )}
      {showSalesData && (
        <>
          <SalesData userRole="Compliance Officer" onBack={handleBackClick} />
        </>
      )}
      <LogoutButton />
    </div>
  );
}

export default ComplianceOfficer;
