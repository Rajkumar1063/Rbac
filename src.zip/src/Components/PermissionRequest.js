import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';

function PermissionRequest({ userRole }) {
  const [requests, setRequests] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newRequest, setNewRequest] = useState('');

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = () => {
    axios.get('/api/requests')
      .then(response => setRequests(response.data))
      .catch(error => console.error('Error fetching requests:', error));
  };

  const handleAddRequest = () => {
    if (!newRequest) return;

    const request = {
      id: Date.now(),
      role: userRole,
      request: newRequest,
      status: 'Pending'
    };

    axios.post('/api/requests', request)
      .then(() => {
        fetchRequests();
        setShowModal(false);
      })
      .catch(error => console.error('Error adding request:', error));
  };

  const handleUpdateRequest = (requestId, status) => {
    axios.put(`/api/requests/${requestId}`, { status })
      .then(() => fetchRequests())
      .catch(error => console.error('Error updating request:', error));
  };

  return (
    <div>
      <h2>Permission Requests</h2>
      {userRole === 'Data Analyst' && (
        <div>
          <Button className="mb-3" onClick={() => setShowModal(true)}>Request Permission</Button>
          <Modal show={showModal} onHide={() => setShowModal(false)}>
            <Modal.Header closeButton>
              <Modal.Title>Request Permission</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form>
                <Form.Group controlId="permissionRequest">
                  <Form.Label>Request</Form.Label>
                  <Form.Control 
                    type="text" 
                    value={newRequest} 
                    onChange={(e) => setNewRequest(e.target.value)} 
                    placeholder="Enter your request" 
                    required 
                  />
                </Form.Group>
                <Button variant="primary" onClick={handleAddRequest}>Submit Request</Button>
              </Form>
            </Modal.Body>
          </Modal>
        </div>
      )}
      {userRole === 'System Admin' && (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>ID</th>
              <th>Role</th>
              <th>Request</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {requests.map(request => (
              <tr key={request.id}>
                <td>{request.id}</td>
                <td>{request.role}</td>
                <td>{request.request}</td>
                <td>{request.status}</td>
                <td>
                  <Button variant="success" className="mr-2" onClick={() => handleUpdateRequest(request.id, 'Approved')}>Approve</Button>
                  <Button variant="danger" onClick={() => handleUpdateRequest(request.id, 'Denied')}>Deny</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </div>
  );
}

export default PermissionRequest;
